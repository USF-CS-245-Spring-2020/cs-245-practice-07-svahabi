public class ArrayQueue<T> implements Queue<T>
{
    private T[] arr;
    private int front;
    private int back;
    private int size;

    public ArrayQueue(){
        size = 0;
        front = 0;
        back = -1;
        arr = (T[])new Object[10];
    }

    public void enqueue(T item) {

        if(size == arr.length)
        {
            doubleArray();
            arr[++back] = item;
        }
        else
        {
            int arrPos = ++back % arr.length;
            arr[arrPos] = item;
        }
        size++;
    }

    public T dequeue() throws Exception
    {
        if(size == 0)
        {
            throw new Exception("Empty Queue");
        }
        size--;
        return arr[front++];
    }





    public boolean empty()
    {
        return size == 0;
    }


    protected void doubleArray()
    {
        T[] temp = (T[])new Object[arr.length*2];
        for(int i = 0; i < size; i++)
        {
            temp[i] = arr[i];
        }
        arr = temp;
    }

}