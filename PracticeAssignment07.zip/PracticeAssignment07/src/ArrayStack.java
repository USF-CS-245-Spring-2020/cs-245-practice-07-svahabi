public class ArrayStack<T> implements Stack<T>
{
    private int top;
    private T[] arr;

    public ArrayStack()
    {
        top = 0;
        arr = (T[])new Object[10];;
    }

    @Override
    public void push(T item)
    {

        if(top == arr.length)
        {
            doubleArray();
        }
        arr[top++] = item;
    }

    @Override
    public T pop() throws Exception
    {

        if(top == 0)
        {
            throw new Exception("Empty Stack");
        }
        return arr[--top];
    }

    @Override
    public T peek() throws Exception
    {

        if(top == 0)
        {
            throw new Exception("Empty Stack");
        }
        return arr[top];
    }

    @Override
    public boolean empty()
    {
        return top == 0;
    }

    protected void doubleArray()
    {
        T[] temp = (T[])new Object[top*2];
        for(int i = 0; i < top; i++)
        {
            temp[i] = arr[i];
        }
        arr = temp;
    }
}